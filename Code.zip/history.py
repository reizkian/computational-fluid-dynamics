# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***

## ---(Tue Jul 31 10:11:34 2018)---
2+3

## ---(Tue Jul 31 18:55:53 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/temp.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/temp.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
deriv(10)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/temp.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
differential(x,0)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/temp.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
differential(10)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/temp.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
differential(10,3)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/temp.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/adding tuple elements.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
t
x
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/adding tuple elements.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
differential(2,3)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Wed Aug  1 00:29:52 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
y_distance(10)
x_distance(10)
vy(10)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
y_distance(100)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Wed Aug  1 01:41:50 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Wed Aug  1 02:19:52 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
%clear
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
%clear
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Sat Aug  4 08:04:44 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/adding tuple elements.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Sat Aug 11 17:57:56 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Fri Aug 17 20:58:45 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Wed Aug 22 10:51:47 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler 2nd.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler 2nd.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler 2nd.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler 2nd.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
%clear
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler 2nd.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
%clear
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler 2nd.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
%clear
%clear
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler 2nd.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/compare 1st_2nd.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler 2nd.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/compare 1st_2nd.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/compare 1st_2nd.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/compare 1st_2nd.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/compare 1st_2nd.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/compare multistepl.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/runge kutta.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
differential(4/2,0)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/runge kutta.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/polar.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
y(1/6)
y(0.5)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/polar.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
import numpy as np
import matplotlib.pyplot as plt

#VARIABLE DEFINITION
r=1.0
t=np.linspace(0,2,31)

#Coordinate functian
def x(t):
    x=1+r*np.cos(np.pi*t)
    return x


def y(t):
    y=r*np.sin(np.pi*t)
    return y
import numpy as np
import matplotlib.pyplot as plt

#VARIABLE DEFINITION
r=1.0
t=np.linspace(0,2,31)

#Coordinate functian
def x(t):
    x=r*np.cos(np.pi*t)
    return x


def y(t):
    y=r*np.sin(np.pi*t)
    return y
x(1)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/template.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
a(2)
b(2)
a(b(2))
b(a(2))
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/2nd Order Euler.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
h=0.1 "PERFORMACE"
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/2nd Order Euler.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Terminal Velocity.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
aya_15/383192/PA/16852
program: Euler Method_practice
created: 31 Juli 2018
"""

import numpy as np
import matplotlib.pyplot as plt

def differential(v,t):
    g= 9.8 #m/s
    k=10
    m=1 #kg
    
    dv_dt=g-(k*v/m)
    return dv_dt
def differential(v,t):
    g= 9.8 #m/s
    k=10
    m=1 #kg
    
    dv_dt=g-(k*v/m)
    return dv_dt
differential(0,0)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Terminal Velocity.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Fri Aug 24 12:31:00 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/test.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
fac(3)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/test.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
fac(3)
fac(-10)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Terminal Velocity.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Terminal Velocity.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Mon Sep  3 13:51:22 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Terminal Velocity.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Pembakaran_Euler.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
du_dt(0.5)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Pembakaran_Euler.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
du_dt(1,0)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Pembakaran_Euler.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Pembakaran_Euler.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Fri Sep  7 12:50:08 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Pembakaran_Euler.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
2+3
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Driven Oscilation.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Test Drive.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
Fn(0,np.pi,0)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Test Drive.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
Fn(phi,omega,0)
Fn(phi_0,omega,0)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Test Drive.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
e
1/e
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Test Drive.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled3.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
x(0)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled3.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
x(0)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled3.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled3.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
z
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled3.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/2nd Order ODE.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Driven Oscilation.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/2nd Order ODE.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Terminal Velocity.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Sun Sep  9 08:50:20 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/2nd Order ODE.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Wed Sep 12 11:13:33 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Kuramoto-Shivashinsky.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Mon Sep 17 14:33:44 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled3.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
a.dtype
len(a)
np.arange(12)
np.arange(12).reshape((3,4))
a.shape
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled3.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
a.T
a
a[2:,:]
a[1:,:]
a[0:,:]
a[:2,:]
a[:1,:]
from numpy import
from numpy import *
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled3.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
M=array([ (10,20), (30,40), (50,60) ])
M=np.array([ (10,20), (30,40), (50,60) ])
M
from visual import *
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled3.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')



adsa
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled3.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
np.zeros(10)
np.zeros(10,2)
np.zeros(10:2)
np.zeros((10,2),float)
debugfile('C:/Users/Reizkian Yesaya/.spyder-py3/EqHeat.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/EqHeat.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
debugfile('C:/Users/Reizkian Yesaya/.spyder-py3/EqHeat.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/EqHeat.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
debugfile('C:/Users/Reizkian Yesaya/.spyder-py3/EqHeat.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/EqHeat.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/decay.animation.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/EqHeat.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Mon Sep 17 20:48:53 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/EqHeat.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
zeros(2)
zeros((2),float)
zeros((1,2),float)
zeros((2),float)
zeros((3,2),float)
y=zeros((2),float)
y[0]
y[0]=3
y[1]=-5
y
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
f(2,y[3,4])
f(2,3)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
y[0]=3;y[1]=4
f(2,y)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
y[0]=3;y[1]=4
k1 = [0]
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/EqHeat.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/EqHeat.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
%matplotlib qt
%matplotlib qt5
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/EqHeat.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
%matplotlib inline
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/EqHeat.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Driven Oscilation.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/decay.animation.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
%matplotlib qt5
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/decay.animation.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
%matplotlib inline
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
sqrt(2)
from numy import *
from numpy import *
sqrt(2)

from numpy import *
pi

## ---(Tue Sep 18 20:20:00 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Driven Oscilation.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/2nd Order ODE.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/2nd Order ODE.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/2nd Order ODE.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/2nd Order ODE.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Wed Sep 19 14:18:11 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
from visual import *
from vpython import *
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
pip install vpython
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Fri Sep 21 11:33:11 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Fri Sep 21 11:47:59 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/EqHeat.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
y(2)
c(2)
c(5)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Pembakaran_Euler.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
integral(0,1,1)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
integral(0,1,1)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
integral(0,0,1)
integral(0,1,1)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
integral(0,1,1)
integral(0,1,2)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled1.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
integral(0,1)
f(2)
integral(0,1)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled1.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
integral(0,1)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled1.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
integral(0,1)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
integral(0,1,1)
Q(2,2)
integral(0,1,2)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
integral(0,1,2)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
integral(0,1,2)

## ---(Fri Sep 21 20:08:23 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Sat Sep 22 11:05:07 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Pembakaran_Euler.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
integral(0,1,2)
vn(0,0,0)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
vn(0,0,0)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
vn(0,0,0)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
vn(0,0,0)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
vn(0,0,0)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
len(PHI)
len(V)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Sun Sep 23 23:02:58 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled4.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled4.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
y(2)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled4.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
y(9)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled4.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
y(1)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled5.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
np.pi*2/0.01

## ---(Mon Sep 24 10:25:44 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/EqHeat.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/VPython.Demo/Bounce.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3/VPython.Demo')

## ---(Mon Sep 24 12:45:41 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/VPython.Demo/Bounce.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3/VPython.Demo')
conda info --envs

## ---(Mon Sep 24 13:07:03 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/VPython.Demo/Bounce.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3/VPython.Demo')
%qt5
%qt4
%backend qt4
%backend qt5
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
%matplotlib qt5
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
%matplotlib inline
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Mon Sep 24 15:55:26 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/VPython.Demo/Bounce.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3/VPython.Demo')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Fri Oct  5 09:44:01 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Navier-Stokes.Beam.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
a
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Navier-Stokes.Beam.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
a
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Navier-Stokes.Beam.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
a
2+a
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Navier-Stokes.Beam.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
matrix1=array(([0,1],[1,3]))
import numpy as np
matrix1=np.array(([0,1],[1,3]))
matrix1
matrix1*matrix1
matrix1[0,0]
matrix1[0,1]
matrix1[1,1]
np.zeros(10)
np.zeros(10,float)
dot(matrix1,matrix1)
np.dot(matrix1,matrix1)

## ---(Fri Oct  5 12:33:22 2018)---
%gui qt
from mayavi import mlab
%gui qt
from mayavi import mlab

## ---(Fri Oct  5 16:19:46 2018)---
%gui qt
from mayavi import mlab

## ---(Fri Oct  5 22:21:46 2018)---
%giu qt
%gui qt
from mayavi import mlab
mlab.test_contour3d()
mlab.test_contour3d
mlab.test_quiver3d
mlab.test_quiver3d()
mlab.test_triangular_mesh()
mlab.test_flow_anim()
mlab.test_contour3d_anim()
mlab.test_mesh??
from vpython import *
%gui qt5
from vpython import *
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/VPython.Demo/AtomicSolid.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3/VPython.Demo')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/VPython.Demo/Plot3D.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3/VPython.Demo')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/VPython.Demo/BoxLightTest.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3/VPython.Demo')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled2.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled2.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/VPython.Demo/BoxLightTest.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3/VPython.Demo')
%gui qt5
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/VPython.Demo/BoxLightTest.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3/VPython.Demo')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Driven Oscilation.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Driven Oscilation_ETD.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Test Drive.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Driven Oscilation_ETD.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Driven Oscilation_ETD.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Driven Oscilation_ETD.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
import mpl_toolkit
import mpl_toolkits
from mpl_toolkits.mplot3d import Axes3D
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Driven Oscilation_ETD.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/inv_A.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled8.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/inv_A.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled8.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/inv_A.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Driven Oscilation_ETD.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Sat Oct  6 20:22:31 2018)---
from mayavi import mlab
mlab.test_contour3d??
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled8.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
%gui qt
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled8.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
mlab.test_contour3d()
mlab.test_fancy_mesh()
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled8.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
import numpy as np
from mayavi import mlab
def test_contour3d():
    x, y, z = np.ogrid[-5:5:64j, -5:5:64j, -5:5:64j]

    scalars = x * x * 0.5 + y * y + z * z * 2.0

    obj = contour3d(scalars, contours=4, transparent=True)
    return obj

mlab.test_contour3d??
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled8.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Sun Oct 14 07:40:55 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Driven Oscilation_ETD.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Thu Oct 18 21:23:46 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Fri Oct 19 19:53:04 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Thu Nov  1 21:17:47 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled8.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Fri Nov  2 17:52:12 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/inv_A.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Driven Oscilation_ETD.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
V
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
V
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
V
import mlab
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Wed Nov  7 08:43:32 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled6.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
x
y
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled6.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
from mayavi import mlab
%gui qt5
mlab.test_contour3d
mlab.test_contour3d()
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled6.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
X
functz(V[1,1])
functz(V)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled6.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
X
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Wed Nov  7 11:22:51 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled6.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
from mlab import mayavi
from mayavi import mlab
%gui qt5
mlab.test_flow_anim()
mlab.test_contour3d()
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled6.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled6.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled6.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
from mayavi import mlab
mlab.test_contour3d()
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled6.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled6.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled6.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Wed Nov  7 13:39:09 2018)---
from mayavi import mlab
mlab.test_contour3d()
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
mlab.test_contour3d()
mlab.clf()
mlab.test_contour3d()
mlab.axes
mlab.Axes
mlab.Axes()
mlab.axes()
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Thu Nov  8 12:53:31 2018)---
from mayavi import mlab
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Fri Nov  9 13:56:40 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
from mayavi import mlab
mlab.test_contour3d()

runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
mlab.test_contour3d()

from mayavi import mlab
mlab.test_contour3d()
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Mon Nov 12 11:39:37 2018)---
from maavi import mlab
from mayavi import mlab
mlab.test_contour3d()
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace_rho.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Mon Nov 12 19:37:03 2018)---
%gui qt5
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
N
L
x
W
W1
k
k1
k11
k
1j**2
import numpy
real(1j**2)
import numpy as np
real(1j**2)
np.real(1j**2)
%gui qt5
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
%gui qt5
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
%gui qt
%gui qt5
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace_rho.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
%matplotlib qt5
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Navier Stokes.Eq_Fahrudin Nugroho.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Matplotlib/ArtistAnimation.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3/Matplotlib')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Navier Stokes.Eq_Fahrudin Nugroho.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
%gui qt5
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/latihan.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
f(5)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/latihan.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/projectile motion.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Navier Stokes.Eq_Fahrudin Nugroho.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/latihan.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
y
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/latihan.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
s = numpy.random.uniform(-1,0,1000)
from numpy import *
s = random.uniform(-1,0,1000)
import numpy as np
s = np.random.uniform(-1,0,1000)
s
s = np.random.uniform(0,1,10)
s
s = np.random.uniform(0,10,10)
s
s = np.random(0,10,10)
s = np.random.uniform(0,10,10)
s
s = np.random.uniform(-1,1,10)
s
s = np.random.uniform(-1,1,[5,5])
s
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
from mayavi import mlab
mlab.test_contour3d()
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Navier Stokes.Eq_Fahrudin Nugroho.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
import numpy as np
q=np.arange(0,10,1)
q
q*2
q.reshape(2,)
(q).reshape(2,)
(q).reshape(20,)
(q).reshape(10,)
(q).reshape(,10)
q
o=0
np.hstack(o,q)
np.hstack((o,q))
np.hstack((q,o))
q**@
q**2
np.arange(6)
np.arange(6).reshape(2,3)
for x in np.nditer(a.T, order='C'):
for x in np.nditer(a.T, order='C'): print(x)
np.arange(6)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Matplotlib/ArtistAnimation.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3/Matplotlib')
%gui qt5
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Matplotlib/ArtistAnimation.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3/Matplotlib')

## ---(Thu Nov 15 10:29:34 2018)---
a=an.arange(0,100,100)
a=np.arange(0,100,100)
import numpy as np
a=np.arange(0,100,100)
a
a=np.linspace(0,100,100)
a
a=np.linspace(1,100,100)
a
len(a)
a=np.arange(0,10,0.5)
len(a)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Kuramoto-Shivashinsky.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Heat.eq Finite Difference.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Heat.eq Finite Difference.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
import numpy as np
import matplotlib.pylab as plab
import mayavi.mlab as mlab

Nmax = 100
Niter = 200
h=0.01
mu=1
V = np.zeros((Nmax,Nmax),float)

V[k,50]=1000
import numpy as np
import matplotlib.pylab as plab
import mayavi.mlab as mlab

Nmax = 100
Niter = 200
h=0.01
mu=1
V = np.zeros((Nmax,Nmax),float)

V[0,50]=1000
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Heat.eq Finite Difference.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Heat.eq Finite Difference.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Heat.eq Finite Difference.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Heat.eq Finite Difference.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
from mayavi import mlab
mlab.test_quiver3d()
mlab.test_flow()
import numpy as np
import matplotlib.pyplot as plt

N=100
Niter = 10
A=np.zeros(N)

A[50]=100

for k in range (Niter):
	for i in range(100):
		A[i]=(A[i-1]+A[i+1])/2


x=np.arange(0,100,1)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Sat Nov 17 07:02:39 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
Me
np.e-31
np.e
import numpy as np
a=np.array([1,2],[3,4])
a=np.array([1,2];[3,4])
a=np.array([[1,2],[3,4]])
a
a.T
np.det(a)
a.max
a
a.t
inv(a)
np.inv(a)
np.invert(a)
a*np.invert(a)
a*a
np.dot(a,a)
a
np.dot(a,np.invert(a))
np.dot(a,np.linalg.inv(a))
import numpy as np

A=np.array([[2,4],[1,-1]])
eq=np.array([[16],[-1]])
A
eq
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
np.linalg.det(A)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
P
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
P
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
P
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
P
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
z=np.arange(1,1,100)
z
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
3*np.pi/2
P
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled1.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
P
alpha
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
alpha
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
alpha
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Sat Nov 17 21:15:55 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Navier Stokes.Eq_Fahrudin Nugroho.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
import numpy as np
np.sech(0)
np.cosh(0)
1/(np.sech(0))
1/(np.cosh(0))
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Simple3Dplot.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled7.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Heat.eq_Spectral.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled7.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Tue Nov 20 07:40:16 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/FFT.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
import numpy as np
np.fft.fft(100)
np.fft.fft(y)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/FFT.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/FFT.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
omega
5*omega
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/FFT.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
omega*10
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/FFT.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
4.45/omega
5.67/omega
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Heat.eq_Spectral.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Matplotlib/ArtistAnimation.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3/Matplotlib')
import numpy as np
import matplotlib.pyplot as plt

l=1
N=256
dx=l/N
x_array=np.arange(1-N/2,N/2+1,1)
x=x_array*dx
xp=np.linspace(-1,1,N)

nu=0.01
T=5

dk=np.pi/l
k_plus=np.arange(0,129,1)
k_minus=np.arange(-127,0,1)
k_array=np.hstack((k_plus,k_minus))
k=k_array*dk
k2=k**2

u0=1/(np.cosh(10.0*x)**2)
u0_hat=np.fft.fft(u0)
j
0+j
o+np.j
0+np.j
import numpy as np
(0+np.j)**2
1j
(1j)**2
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
len(x)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
int(5/2)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
sum(a)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
sum(u)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
sum(u)
a=[1,2,3]
sum(a)
sum(u)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
sum(u)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
sum(u)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
a(2)
a(4)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/untitled0.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
u(0)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Heat.eq_Spectral.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
u(0)
u(1)
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Heat.eq_Spectral.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Heat.eq_Spectral.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Heat.eq_Spectral.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Wed Nov 21 13:06:36 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Navier Stokes.Eq_Fahrudin Nugroho.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Heat.eq_Spectral.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Thu Nov 22 21:14:52 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/euler method.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Fri Nov 23 14:06:17 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Sat Nov 24 18:41:08 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Sun Nov 25 19:33:05 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Wed Nov 28 12:08:21 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Thu Nov 29 11:50:31 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/Laplace.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')

## ---(Thu Nov 29 20:03:08 2018)---
runfile('G:/tugasmnist/imp_01.py', wdir='G:/tugasmnist')
runfile('D:/tugasmnist/imp_01.py', wdir='D:/tugasmnist')
runfile('D:/tugasmnist/cm.py', wdir='D:/tugasmnist')

## ---(Thu Dec  6 11:08:30 2018)---
runfile('C:/Users/Reizkian Yesaya/.spyder-py3/E X P E R I M E N T.py', wdir='C:/Users/Reizkian Yesaya/.spyder-py3')